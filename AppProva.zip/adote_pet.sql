CREATE TABLE Pet (
  Id int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  nome varchar(100) DEFAULT NULL,
  especie varchar(100) DEFAULT NULL,
  animal varchar(100) DEFAULT NULL,
  data_nasc date DEFAULT NULL,
  peso double DEFAULT NULL,
  vacinado smallint(6) DEFAULT NULL,
  sobre varchar(100) DEFAULT NULL
) ENGINE=InnoDB;

CREATE TABLE Tutor (
  Id int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  cpf varchar(20) DEFAULT NULL,
  nome varchar(100) DEFAULT NULL,
  telefone varchar(100) DEFAULT NULL,
  email varchar(100) DEFAULT NULL,
  data_nasc date DEFAULT NULL,
  cep varchar(20) DEFAULT NULL,
  uf char(2) DEFAULT NULL,
  cidade varchar(100) DEFAULT NULL,
  bairro varchar(100) DEFAULT NULL,
  logradouro varchar(100) DEFAULT NULL,
  numero int(11) DEFAULT NULL
) ENGINE=InnoDB;
CREATE TABLE Adocao (
  Id int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
  fk_Tutor_Id int(11) DEFAULT NULL,
  fk_Pet_Id int(11) DEFAULT NULL,
  data_adocao DATETIME DEFAULT current_timestamp,
  FOREIGN KEY(fk_Tutor_Id) REFERENCES Tutor(Id),
  FOREIGN KEY(fk_Pet_Id) REFERENCES Pet(Id)
) ENGINE=InnoDB;


INSERT INTO tutor (Id, cpf, nome, telefone, email, data_nasc, cep, uf, cidade, bairro, logradouro, numero) VALUES ('', '11122233300', 'Eliton Camargo de Oliveira', '(14)99988-7766', 'elitonoliveira@fatec.sp.gov.br', '1988-11-16', '13550-00', 'SP', 'Tietê', 'Serra', 'Rua Teste', '100');
INSERT INTO pet (Id, nome, especie, animal, data_nasc, peso, vacinado, sobre) VALUES (NULL, 'Pingo', 'Mamífero ', 'Cachorro', '2022-11-01', '1', '1', 'Lindinho');
INSERT INTO adocao (fk_Tutor_Id, fk_Pet_Id, data_adocao) VALUES ('1', '1');