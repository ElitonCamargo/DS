﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            string cmdSql = "INSERT INTO filme VALUES ('Teste','2010',5,1,'Teste comentário')";
            if(Program.cx.INSERT(cmdSql) > 0 ) 
            {
                MessageBox.Show("Cadastrado com sucesso");
            }
            else 
            {
                MessageBox.Show("Erro de cadastro");
            }
        }
    }
}
