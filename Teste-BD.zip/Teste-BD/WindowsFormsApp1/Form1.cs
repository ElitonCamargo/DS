﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void carregarDt() 
        {
            dtDados.Rows.Clear();
            string cmdSql = "SELECT * FROM filme";
            DataTable listaFilmes = Program.cx.SELECT(cmdSql);
            if (listaFilmes != null) 
            {                
                foreach (DataRow linha in listaFilmes.Rows) 
                {
                    dtDados.Rows.Add(
                        linha[1],linha[2], linha[3], linha[4], linha[5]
                    );
                }                
            }
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            string nome = txtNome.Text;
            string ano = txtAno.Text;
            string avaliacao = cbAvaliacao.Text;
            int like = chckLike.Checked? 1 : 0;
            string comentario = txtComentario.Text;

            string cmdSql = $"CALL filme_cadastrar('{nome}','{ano}','{avaliacao}','{like}','{comentario}')";
               
            if(Program.cx.INSERT(cmdSql) > 0 ) 
            {
                MessageBox.Show("Cadastrado com sucesso");
                carregarDt();
            }
            else 
            {
                MessageBox.Show("Erro de cadastro");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            carregarDt();
        }
    }
}
